#ifndef _FILTERING_TEST_GROUP_H_
#define _FILTERING_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(filtering_tests);

#endif /* _FILTERING_TEST_GROUP_H_ */
